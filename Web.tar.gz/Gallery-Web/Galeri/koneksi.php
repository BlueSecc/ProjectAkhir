<?php
    $conn=mysqli_connect("localhost","ayam","ayam","galeri");
?>
